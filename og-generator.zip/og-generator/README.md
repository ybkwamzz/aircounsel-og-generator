# AirCounsel OG Image Generator

Generates branded 1200×630 PNG Open Graph images for all AirCounsel
pillar pages. Runs locally via Node.js and Puppeteer.

---

## Setup

```bash
npm install
```

Requires Chrome or Chromium installed on your machine.

---

## Usage

### Generate all four pillar pages at once
```bash
node generate.js
```

### Generate a single page
```bash
node generate.js --page benchmark
node generate.js --page skilled-worker
node generate.js --page intake
node generate.js --page whitepaper
```

### List available pages
```bash
node generate.js --list
```

### Generate a custom one-off image
```bash
node generate.js \
  --title "Your Page Title" \
  --label "Category · Context" \
  --desc "One sentence description of the page." \
  --badge "White Paper" \
  --cta "Read the Paper →" \
  --out "og-custom.png"
```

### Specify Chrome path manually (if not auto-detected)
```bash
node generate.js --chrome "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
```

---

## Output

All PNGs are saved to the `/output` folder at 2x resolution (2400×1260)
for retina sharpness, displayed at 1200×630.

---

## After generating

1. Upload PNGs to `aircounsel.uk/assets/og/`
2. Add to each page `<head>`:

```html
<!-- Benchmark Report -->
<meta property="og:image" content="https://aircounsel.uk/assets/og/og-benchmark-report.png">
<meta name="twitter:image" content="https://aircounsel.uk/assets/og/og-benchmark-report.png">

<!-- Skilled Worker -->
<meta property="og:image" content="https://aircounsel.uk/assets/og/og-skilled-worker.png">
<meta name="twitter:image" content="https://aircounsel.uk/assets/og/og-skilled-worker.png">

<!-- Intake Guide -->
<meta property="og:image" content="https://aircounsel.uk/assets/og/og-intake-guide.png">
<meta name="twitter:image" content="https://aircounsel.uk/assets/og/og-intake-guide.png">

<!-- White Paper -->
<meta property="og:image" content="https://aircounsel.uk/assets/og/og-whitepaper.png">
<meta name="twitter:image" content="https://aircounsel.uk/assets/og/og-whitepaper.png">
```

3. Validate on LinkedIn using:
   https://www.linkedin.com/post-inspector/

---

## Adding new pages

Open `generate.js` and add a new entry to the `PAGES` object:

```js
'my-new-page': {
  key:   'my-new-page',
  badge: 'Guide',
  label: 'Category · Context',
  title: 'Your Title\nSecond Line',
  desc:  'One sentence description.',
  cta:   'Read the Guide →',
  out:   'og-my-new-page.png',
},
```

Use `\n` in the title to force a line break.
