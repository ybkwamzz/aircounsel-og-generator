#!/usr/bin/env node

/**
 * ═══════════════════════════════════════════════════════
 * AIRCOUNSEL — OG IMAGE GENERATOR CLI
 * ═══════════════════════════════════════════════════════
 *
 * SETUP:
 *   npm install
 *   node generate.js              ← generates all 4 pillar pages
 *   node generate.js --page sw    ← generates one page
 *   node generate.js --list       ← shows available pages
 *
 * CUSTOM PAGE:
 *   node generate.js \
 *     --title "Your Title" \
 *     --label "Your Label" \
 *     --desc "Your description" \
 *     --badge "White Paper" \
 *     --cta "Read the Paper →" \
 *     --out "custom-og.png"
 * ═══════════════════════════════════════════════════════
 */

const puppeteer = require('puppeteer-core');
const path      = require('path');
const fs        = require('fs');
const args      = require('./args');

// ── OUTPUT DIRECTORY ──────────────────────────────────
const OUT_DIR = path.resolve(__dirname, 'output');
if (!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR, { recursive: true });

// ── PILLAR PAGE CONFIGS ───────────────────────────────
const PAGES = {
  benchmark: {
    key:   'benchmark',
    badge: 'Benchmark Report',
    label: 'UK Immigration Intake · 2026',
    title: 'The 2026 UK Immigration\nIntake Benchmark Report',
    desc:  'Data, trends, and operational insights from across the UK immigration sector — for practices seeking a measurable performance standard.',
    cta:   'Read the Report →',
    out:   'og-benchmark-report.png',
  },
  'skilled-worker': {
    key:   'skilled-worker',
    badge: 'Route Analysis',
    label: 'Skilled Worker · Immigration Rules',
    title: 'Skilled Worker Visa:\nThe Complete Threshold Analysis',
    desc:  'Salary thresholds, eligibility gates, and qualification criteria — structured for practitioners and calibrated to 2026 Immigration Rules.',
    cta:   'Read the Analysis →',
    out:   'og-skilled-worker.png',
  },
  intake: {
    key:   'intake',
    badge: 'Intake Guide',
    label: 'Operational Standard · UK Immigration',
    title: 'The UK Immigration\nFirm Intake Guide',
    desc:  'How high-performing UK immigration practices structure, qualify, and convert enquiries — before a solicitor is involved.',
    cta:   'Read the Guide →',
    out:   'og-intake-guide.png',
  },
  whitepaper: {
    key:   'whitepaper',
    badge: 'White Paper',
    label: 'AirCounsel · Research',
    title: 'The First Mile: Why Intake\nDetermines Legal Outcomes',
    desc:  'How the quality of information at intake determines the quality of legal work downstream — and the operational cost of the gap.',
    cta:   'Read the Paper →',
    out:   'og-whitepaper.png',
  },
};

// ── HTML TEMPLATE ─────────────────────────────────────
function buildHTML(cfg) {
  const titleLines = cfg.title.split('\n').join('<br>');
  return `<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>
  @import url('https://fonts.googleapis.com/css2?family=Unbounded:wght@400;700&family=DM+Mono:wght@400;500&display=swap');

  * { margin: 0; padding: 0; box-sizing: border-box; }

  body {
    width: 1200px;
    height: 630px;
    overflow: hidden;
    background: #07070F;
    font-family: 'DM Mono', 'Courier New', monospace;
    position: relative;
  }

  .grid {
    position: absolute;
    inset: 0;
    background-image:
      linear-gradient(rgba(0,212,255,0.03) 1px, transparent 1px),
      linear-gradient(90deg, rgba(0,212,255,0.03) 1px, transparent 1px);
    background-size: 60px 60px;
  }

  .glow-tl {
    position: absolute;
    top: -120px; left: -80px;
    width: 400px; height: 400px;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(0,212,255,0.07) 0%, transparent 70%);
  }

  .glow-br {
    position: absolute;
    bottom: -100px; right: -60px;
    width: 360px; height: 360px;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(255,107,26,0.06) 0%, transparent 70%);
  }

  .v-rule {
    position: absolute;
    left: 460px; top: 24px; bottom: 24px;
    width: 1px;
    background: linear-gradient(180deg,
      transparent,
      rgba(0,212,255,0.06) 25%,
      rgba(0,212,255,0.06) 75%,
      transparent
    );
  }

  .frame {
    position: absolute;
    inset: 24px;
    border: 1px solid rgba(0,212,255,0.08);
  }

  .corner { position: absolute; width: 18px; height: 18px; }
  .corner.tl { top:-1px; left:-1px; border-top:2px solid rgba(0,212,255,0.45); border-left:2px solid rgba(0,212,255,0.45); }
  .corner.tr { top:-1px; right:-1px; border-top:2px solid rgba(0,212,255,0.15); border-right:2px solid rgba(0,212,255,0.15); }
  .corner.bl { bottom:-1px; left:-1px; border-bottom:2px solid rgba(255,107,26,0.15); border-left:2px solid rgba(255,107,26,0.15); }
  .corner.br { bottom:-1px; right:-1px; border-bottom:2px solid rgba(255,107,26,0.4); border-right:2px solid rgba(255,107,26,0.4); }

  .inner {
    position: absolute;
    inset: 0;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    padding: 52px 72px;
  }

  /* TOP BAR */
  .top-bar {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
  }

  .brand-name {
    font-family: 'Unbounded', sans-serif;
    font-size: 16px;
    font-weight: 700;
    color: #ffffff;
    letter-spacing: 0.08em;
  }

  .brand-name span { color: rgba(0,212,255,0.85); }

  .brand-url {
    font-size: 9px;
    letter-spacing: 0.25em;
    color: rgba(255,255,255,0.2);
    text-transform: uppercase;
    margin-top: 5px;
  }

  .top-right {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    gap: 7px;
  }

  .badge {
    font-size: 8px;
    letter-spacing: 0.3em;
    text-transform: uppercase;
    color: rgba(255,107,26,0.8);
    border: 1px solid rgba(255,107,26,0.2);
    padding: 5px 12px;
  }

  .pub-date {
    font-size: 8px;
    letter-spacing: 0.2em;
    color: rgba(255,255,255,0.18);
  }

  /* CENTRE */
  .title-block {
    display: flex;
    flex-direction: column;
    gap: 16px;
    max-width: 820px;
  }

  .page-label {
    font-size: 10px;
    letter-spacing: 0.35em;
    text-transform: uppercase;
    color: rgba(0,212,255,0.55);
  }

  .page-title {
    font-family: 'Unbounded', sans-serif;
    font-size: 42px;
    font-weight: 700;
    color: #ffffff;
    line-height: 1.15;
    letter-spacing: -0.01em;
  }

  .page-desc {
    font-size: 13px;
    line-height: 1.75;
    color: rgba(255,255,255,0.32);
    letter-spacing: 0.03em;
    max-width: 640px;
  }

  /* BOTTOM */
  .bottom-bar {
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
  }

  .compliance-row {
    display: flex;
    gap: 20px;
    align-items: center;
  }

  .comp-item {
    font-size: 8px;
    letter-spacing: 0.2em;
    text-transform: uppercase;
    color: rgba(255,255,255,0.18);
    display: flex;
    align-items: center;
    gap: 6px;
  }

  .comp-dot {
    width: 4px; height: 4px;
    border-radius: 50%;
    background: rgba(0,212,255,0.3);
  }

  .cta-tag {
    font-size: 9px;
    letter-spacing: 0.3em;
    text-transform: uppercase;
    color: rgba(0,212,255,0.65);
    border: 1px solid rgba(0,212,255,0.18);
    padding: 9px 20px;
  }
</style>
</head>
<body>
  <div class="grid"></div>
  <div class="glow-tl"></div>
  <div class="glow-br"></div>
  <div class="v-rule"></div>
  <div class="frame">
    <div class="corner tl"></div>
    <div class="corner tr"></div>
    <div class="corner bl"></div>
    <div class="corner br"></div>
  </div>
  <div class="inner">
    <div class="top-bar">
      <div>
        <div class="brand-name">AIR<span>COUNSEL</span></div>
        <div class="brand-url">aircounsel.uk</div>
      </div>
      <div class="top-right">
        <div class="badge">${cfg.badge}</div>
        <div class="pub-date">Published Q1 2026</div>
      </div>
    </div>
    <div class="title-block">
      <div class="page-label">${cfg.label}</div>
      <div class="page-title">${titleLines}</div>
      <div class="page-desc">${cfg.desc}</div>
    </div>
    <div class="bottom-bar">
      <div class="compliance-row">
        <div class="comp-item"><div class="comp-dot"></div>GDPR-Aligned</div>
        <div class="comp-item"><div class="comp-dot"></div>SRA-Compatible</div>
        <div class="comp-item"><div class="comp-dot"></div>Intake Intelligence Engine</div>
      </div>
      <div class="cta-tag">${cfg.cta}</div>
    </div>
  </div>
</body>
</html>`;
}

// ── GENERATE ONE IMAGE ────────────────────────────────
async function generate(cfg, browser) {
  const page = await browser.newPage();
  await page.setViewport({ width: 1200, height: 630, deviceScaleFactor: 2 });
  await page.setContent(buildHTML(cfg), { waitUntil: 'networkidle0' });

  // Wait for Google Fonts to load
  await new Promise(r => setTimeout(r, 1200));

  const outPath = path.join(OUT_DIR, cfg.out);
  await page.screenshot({ path: outPath, type: 'png' });
  await page.close();

  console.log(`  ✓  ${cfg.out}`);
  return outPath;
}

// ── MAIN ──────────────────────────────────────────────
(async () => {
  const parsed = args.parse(process.argv.slice(2));

  // --list
  if (parsed.list) {
    console.log('\nAvailable pages:\n');
    Object.keys(PAGES).forEach(k => console.log(`  --page ${k}`));
    console.log('\nRun without flags to generate all.\n');
    process.exit(0);
  }

  // Determine which configs to run
  let targets = [];

  if (parsed.title) {
    // Custom one-off
    targets.push({
      key:   'custom',
      badge: parsed.badge  || 'AirCounsel',
      label: parsed.label  || 'aircounsel.uk',
      title: parsed.title,
      desc:  parsed.desc   || '',
      cta:   parsed.cta    || 'Read →',
      out:   parsed.out    || 'og-custom.png',
    });
  } else if (parsed.page) {
    const cfg = PAGES[parsed.page];
    if (!cfg) {
      console.error(`\n  Unknown page: "${parsed.page}". Run --list to see options.\n`);
      process.exit(1);
    }
    targets.push(cfg);
  } else {
    // All pages
    targets = Object.values(PAGES);
  }

  // Find Chromium — checks common paths
  const CHROME_PATHS = [
    '/usr/bin/google-chrome',
    '/usr/bin/google-chrome-stable',
    '/usr/bin/chromium-browser',
    '/usr/bin/chromium',
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  ];

  let executablePath = parsed.chrome;
  if (!executablePath) {
    executablePath = CHROME_PATHS.find(p => {
      try { return fs.existsSync(p); } catch { return false; }
    });
  }

  if (!executablePath) {
    console.error(`
  ✗  Chrome / Chromium not found.
     Pass the path explicitly:
     node generate.js --chrome "/path/to/chrome"
    `);
    process.exit(1);
  }

  console.log(`\n  AirCounsel OG Image Generator`);
  console.log(`  Chromium: ${executablePath}`);
  console.log(`  Output:   ${OUT_DIR}\n`);

  const browser = await puppeteer.launch({
    executablePath,
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage'],
    headless: true,
  });

  for (const cfg of targets) {
    await generate(cfg, browser);
  }

  await browser.close();

  console.log(`\n  Done. ${targets.length} image(s) saved to /output\n`);
  console.log(`  Next step: upload PNGs to aircounsel.uk/assets/og/`);
  console.log(`  Then add to each page <head>:\n`);
  console.log(`  <meta property="og:image" content="https://aircounsel.uk/assets/og/og-PAGENAME.png">`);
  console.log(`  <meta name="twitter:image" content="https://aircounsel.uk/assets/og/og-PAGENAME.png">\n`);

})();
